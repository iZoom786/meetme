document.addEventListener("DOMContentLoaded", () => {
    const targetDiv = document.getElementById("embed-target");
    const statusMsg = document.getElementById("status-msg");

    // Your new shortcut/goto URL
    const embedUrl = "https://opensearch.primelakehouse.com/goto/918484d11c7a6a3bf0e683b045a4665d?security_tenant=global";

    const iframe = document.createElement("iframe");
    iframe.src = embedUrl;
    iframe.height = "600";
    iframe.width = "800";
    iframe.title = "Braintree Health View";

    iframe.onload = () => {
        statusMsg.textContent = "Embed loaded successfully.";
        statusMsg.style.color = "green";
    };

    targetDiv.appendChild(iframe);
});

